function download(id){
	window.location.href="http://localhost:8080/downloadFile?id="+id;	
}