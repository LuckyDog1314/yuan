package cn.sh.changxing.bs.vrmt;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.gridfs.GridFSDBFile;
import cn.sh.changxing.mdb.vrmt.MDBGridFSTemplateVRMT;

/**
 * 文件的下载
 * @author niushunyuan
 *
 */
@Controller
@EnableAutoConfiguration
public class SampleController2 {

	// 日志对象
	private static final Logger LOG = LoggerFactory.getLogger(MongodbFileSaveTest.class);

	@Autowired
	private MDBGridFSTemplateVRMT mdbGridFSTemplateVRMT;
	
	//文件下载
	@RequestMapping(value = "downloadFile", method = RequestMethod.GET, produces = "text/html;charset=utf-8")
	@ResponseBody
	public void downloadFile(HttpServletRequest req, HttpServletResponse response) throws IOException {

		LOG.info("文件下载");
		String id=req.getParameter("id");
		
		Query query = new Query(Criteria.where("_id").is(new ObjectId(id)));
		GridFSDBFile gridFSDBFile = mdbGridFSTemplateVRMT.findOne(query);
      
		OutputStream out = response.getOutputStream();
		
		if(gridFSDBFile!=null){
			String filename = gridFSDBFile.getFilename();// 文件名称
			String contentType=gridFSDBFile.getContentType();//文件类型
			String originalFilename=filename+"."+contentType;
			InputStream in = gridFSDBFile.getInputStream();// 文件输入流

			//response.setContentType("application/x-msdownload");
			response.setContentType("application/octet-stream");
			response.setHeader("content-disposition", "attachment;filename="+URLEncoder.encode(originalFilename, "UTF-8"));
			
			try {
				int tempbyte;
				while ((tempbyte = in.read()) != -1) {
					out.write(tempbyte);
				}
				in.close();
				out.flush();
			} catch (IOException e) {
				e.printStackTrace();

			}
		}else{
			//文件不存在时，暂不处理
		}
	}
}
